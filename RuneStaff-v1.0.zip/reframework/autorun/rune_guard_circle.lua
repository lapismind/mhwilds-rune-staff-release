--[[
  rune_guard_circle.lua  --  「剑盾形态下防御时召唤法阵」

  行为：
    · 剑盾形态（get_Mode()==0）：**只有举盾防御时**法阵才显形
    · 斧形态（get_Mode()~=0）：常显（法阵在斧形态就是盾）

  ------------------------------------------------------------------ 它取代什么
  它取代 AVM 的 `reframework\data\ArmorVariantManager\it0900_0021.json`。
  **必须二选一**：AVM 的 `set_Enabled` 是每帧执行的
  （`ArmorVariantManager.lua:933-940`，`should_apply` 只包住缓存更新、不包住它），
  两个写入者会每帧互相覆盖 → 抖动。装上这个脚本就删掉那个 JSON。

  ------------------------------------------------------------------ 数据来源
  GUARD_MOTIONS 是**实测采来的**，不是猜的。2026-09-19 用
  `rune_motion_probe.lua` 采到 10793 帧、242 秒，其中"站定 → 按住 R 防御 →
  松开，重复 3 次"那一段（00:32:22–00:32:53）里出现过的 motion ID 只有：

      0, 200, 201, 202

  `0` 是"没有动作"（站定/移动都算它）。所以防御这个动作 = {200, 201, 202}。
  三次重复都呈现同一个三段式 200 → 201 → 202，且中间隔着 motion=0 的静默段，
  与用户"重复 3 次"的操作一一对应：

     200  约 2.3 秒，三次几乎一样长   -> 举盾（进入防御）
     201  约 2.3~4.8 秒，随人按住多久 -> 防御维持（真正"在防"的状态）
     202  约 0.26 秒，短且固定        -> 收盾（退出防御）

  **三个都收进来**，因为我们要的语义是"整个防御过程都显形"，而不是只在中段显形。
  附带好处：不必赌上面那三行的角色判断哪一行才是对的。

  注意 `200` 在剑盾→斧变形时也会闪一下（实测只有 8 帧 ≈ 0.09 秒）。这个没有副作用：
  那一刻我们正要变形，斧形态本来就是常显。

  ------------------------------------------------------------------ 找不到网格时的行为
  什么都不做（保持原样）。也就是说换一把别的充能斧时，法阵回到原版行为
  （原版就是全形态常显），不会出现"法阵消失"这种坏结果。

  ------------------------------------------------------------------ 失败安全
  脚本出错时**先把法阵恢复成显示**再停用自己。理由：法阵在斧形态就是盾，
  一个"因为脚本崩了所以盾是透明的"状态比"法阵一直显示"糟糕得多。
]]

local LOG_FILE = "rune_guard_circle.log"
local MESH_PREFIX = "it0900_0021_1"      -- 法阵网格的对象名前缀（part 1）
local GUARD_MOTIONS = { [200] = true, [201] = true, [202] = true }
local HYSTERESIS_FRAMES = 3              -- 连续 N 帧判定一致才切换，抗变形瞬间抖动

-- 防御「余辉」：只要在这么长时间内见过防御动作，就仍认为在防御。
--
-- 为什么需要它（2026-09-19 实机日志的发现）：按住 R **一边防御一边走** 时，
-- layer 0 的 motion ID 会在防御组和移动组之间来回跳，大约每秒一次：
--
--     [00:44:29] motion=201 -> 显形
--     [00:44:29] motion=13  -> 隐藏     <- 移动
--     [00:44:31] motion=201 -> 显形     <- 又回来了
--     [00:44:31] motion=11  -> 隐藏
--     ...
--
-- 所以症状不是"移动时不显示"而是**每秒闪一次**（用户看到的正是这个）。
--
-- 为什么不是把 10/11/12/13/41/43 直接加进 GUARD_MOTIONS：那几个 ID 在**非防御**
-- 的移动/变形里也会出现（同一次日志里 41 出现在变形序列里），加进去等于"走路也显形"。
-- 余辉不需要给这些 ID 分类，它只回答"刚才在不在防御"，所以更稳。
local GUARD_GRACE_SECONDS = 2.0

local MAX_LOG_LINES = 400
local MAX_ERRORS = 10
local MESH_RECHECK_FRAMES = 300          -- 网格指针失效时重新查找的间隔


local frame_no = 0
local error_count = 0
local log_lines = 0
local mesh = nil                         -- 缓存的 via.render.Mesh
local last_want = nil
local pending_value, pending_count = nil, 0
local last_change_frame = -MESH_RECHECK_FRAMES


local function stamp()
    return os.date("%H:%M:%S")
end


local function safe(fn, fallback)
    local ok, value = pcall(fn)
    if ok and value ~= nil then return value end
    return fallback
end


local function log(text)
    if log_lines >= MAX_LOG_LINES then return end
    log_lines = log_lines + 1
    pcall(function()
        local handle = io.open(LOG_FILE, "a")
        if handle then
            handle:write("[" .. stamp() .. "] " .. text .. "\n")
            handle:close()
        end
    end)
end


-- 工作目录实测是 <游戏目录>\reframework\data\，所以日志落在那里（同 probe）
pcall(function()
    local handle = io.open(LOG_FILE, "w")
    if handle then
        handle:write("[" .. stamp() .. "] rune_guard_circle 启动\n")
        handle:close()
    end
end)


-- ------------------------------------------------------------------ 引擎接口
local function mesh_of(go)
    local t = sdk.find_type_definition("via.render.Mesh")
    if not t then return nil end
    return safe(function() return go:call("getComponent(System.Type)", t:get_runtime_type()) end, nil)
end


local function game_object_name(go)
    return safe(function() return go:call("get_Name") end, nil)
        or safe(function() return go:ToString() end, "?")
end


-- 在角色层级里深度优先找名字以 MESH_PREFIX 开头的对象，返回它的 via.render.Mesh。
-- 遍历方式照抄 AVM（get_Child / get_Next），那是本地实证过的写法。
local function find_rune_mesh(transform, depth)
    if not transform or depth > 8 then return nil end
    local child = safe(function() return transform:call("get_Child") end, nil)
    local guard = 0
    while child and guard < 256 do
        guard = guard + 1
        local go = safe(function() return child:call("get_GameObject") end, nil)
        if go then
            local name = game_object_name(go) or ""
            if name:sub(1, #MESH_PREFIX) == MESH_PREFIX then
                local m = mesh_of(go)
                if m then return m end
            end
            local found = find_rune_mesh(child, depth + 1)
            if found then return found end
        end
        child = safe(function() return child:call("get_Next") end, nil)
    end
    return nil
end


local function get_character_and_handling()
    local pm = safe(function() return sdk.get_managed_singleton("app.PlayerManager") end, nil)
    if not pm then return nil, nil end
    local master = safe(function() return pm:call("getMasterPlayer") end, nil)
    if not master then return nil, nil end
    for _, route in ipairs({ "get_Character", "get_Object" }) do
        local candidate = safe(function() return master:call(route) end, nil)
        if candidate then
            local wh = safe(function() return candidate:call("get_WeaponHandling") end, nil)
            if wh then return candidate, wh end
        end
    end
    return nil, nil
end


local function acquire_mesh(char)
    if mesh and safe(function() return sdk.is_managed_object(mesh) end, false) then
        return mesh
    end
    mesh = nil
    local go = safe(function() return char:call("get_GameObject") end, nil)
    local tr = go and safe(function() return go:call("get_Transform") end, nil)
    if not tr then return nil end
    mesh = find_rune_mesh(tr, 0)
    if mesh then
        log("找到法阵网格（对象名以 " .. MESH_PREFIX .. " 开头）")
    end
    return mesh
end


-- ------------------------------------------------------------------ 判定
local last_guard_at = nil         -- 最后一次看到防御动作的墙钟秒

local function want_visible(mode, motion_id)
    if mode ~= 0 then
        return true                      -- 斧形态常显（法阵就是盾）
    end
    if GUARD_MOTIONS[motion_id] == true then
        last_guard_at = os.time()
        return true
    end
    -- 余辉：按住防御移动时 motion ID 会跳出去又跳回来，不能一跳出就藏
    if last_guard_at and (os.time() - last_guard_at) < GUARD_GRACE_SECONDS then
        return true
    end
    return false
end


local function ensure_visible_flag(m, want)
    local cur = safe(function() return m:call("get_Enabled") end, nil)
    if cur == want then return false end
    return safe(function() m:call("set_Enabled", want) return true end, false)
end


local function restore_visible()
    -- 失败安全：宁可法阵一直显示，也不要留下一个透明的盾
    if mesh and safe(function() return sdk.is_managed_object(mesh) end, false) then
        ensure_visible_flag(mesh, true)
    end
end


re.on_frame(function()
    frame_no = frame_no + 1
    if error_count >= MAX_ERRORS then return end

    local ok, err = pcall(function()
        local char, wh = get_character_and_handling()
        if not char or not wh then return end

        local m = acquire_mesh(char)
        if not m then
            -- 不是我们的武器 / 还没加载出来：什么都不做
            return
        end

        local mode = safe(function() return wh:call("get_Mode") end, nil)
        if mode == nil then return end

        local mc = safe(function() return char:call("get_MotionComponent") end, nil)
        local layer = mc and safe(function() return mc:call("getLayer", 0) end, nil)
        local mid = layer and safe(function() return layer:call("get_MotionID") end, nil)
        if mid == nil then return end

        local want = want_visible(mode, mid)

        -- 帧数迟滞：变形瞬间 get_Mode 会硬切，单帧抖动不该让法阵闪一下
        if pending_value == want then
            pending_count = pending_count + 1
        else
            pending_value, pending_count = want, 1
        end

        if pending_count >= HYSTERESIS_FRAMES then
            if want ~= last_want then
                last_want = want
                ensure_visible_flag(m, want)
                -- 标明这一帧是"真防御"还是"余辉在撑"，否则日志里看不出区别
                local why = ""
                if want and mode == 0 and GUARD_MOTIONS[mid] ~= true then
                    why = string.format("  (余辉，%.1fs 内见过防御)",
                                        os.time() - (last_guard_at or os.time()))
                end
                log(string.format("mode=%s motion=%s -> 法阵 %s%s",
                    tostring(mode), tostring(mid), want and "显形" or "隐藏", why))
            else
                -- 引擎会自己把 enabled 改回 true（AVM 的代码暗示如此），所以每帧确认一次
                ensure_visible_flag(m, want)
            end
        end
    end)

    if not ok then
        error_count = error_count + 1
        log("error " .. error_count .. ": " .. tostring(err))
        if error_count >= MAX_ERRORS then
            log("连续报错，恢复法阵为显示并停用自己")
            restore_visible()
        end
    end
end)
